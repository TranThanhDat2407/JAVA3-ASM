/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package SOF203_Lab2;

/**
 *
 * @author THANHDAT
 */
public interface Calculator {
    
    void add(double a, double b);
    
    void substract(double a, double b);
    
    void multiply(double a, double b);
    
    void divide(double a, double b);
    
}
