/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SOF203_LAB6;

/**
 *
 * @author THANHDAT
 */
public class standards {
    private String standard;
    private String fees;

    public standards() {
    }

    
    public standards(String standard, String fees) {
        this.standard = standard;
        this.fees = fees;
    }

    public String getStandard() {
        return standard;
    }

    public void setStandard(String standard) {
        this.standard = standard;
    }

    public String getFees() {
        return fees;
    }

    public void setFees(String fees) {
        this.fees = fees;
    }
    
    
}
